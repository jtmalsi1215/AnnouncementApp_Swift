import SwiftUI

struct NewAnnouncementView: View {
    @EnvironmentObject private var store: AnnouncementStore
    @Environment(\.dismiss) private var dismiss

    @State private var title = ""
    @State private var details = ""
    @State private var selectedCategory = AnnouncementCategory.academics.rawValue
    @State private var alertText: String?

    var body: some View {
        VStack(spacing: 0) {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    HeaderPlaceholderView()

                    Spacer().frame(height: 35)

                    HStack(spacing: 6) {
                        Image(systemName: "plus")
                            .font(.system(size: 20, weight: .bold))
                        Text("NEW ANNOUNCEMENT")
                            .font(.system(size: 13, weight: .bold))
                    }
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color(red: 1.0, green: 0.796, blue: 0.271))
                    .clipShape(RoundedRectangle(cornerRadius: 30))

                    Spacer().frame(height: 12)

                    VStack(alignment: .leading, spacing: 0) {
                        FieldLabel(icon: "doc.text", text: "Announcement Title")
                        Spacer().frame(height: 6)
                        TextField("", text: $title)
                            .font(.system(size: 14))
                            .padding(.horizontal, 10)
                            .frame(height: 42)
                            .background(.white)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(.gray.opacity(0.7), lineWidth: 1))

                        Spacer().frame(height: 14)

                        FieldLabel(icon: "square.and.pencil", text: "Details")
                        Spacer().frame(height: 6)
                        TextEditor(text: $details)
                            .font(.system(size: 14))
                            .frame(height: 180)
                            .padding(8)
                            .overlay(RoundedRectangle(cornerRadius: 18).stroke(.gray.opacity(0.7), lineWidth: 1))

                        Spacer().frame(height: 18)

                        FieldLabel(icon: "folder", text: "Category")
                        Spacer().frame(height: 10)

                        FlowLayout(spacing: 8, rowSpacing: 8) {
                            ForEach(AnnouncementCategory.allCases) { category in
                                CategoryChip(category: category.rawValue, selected: selectedCategory == category.rawValue, smallText: true) {
                                    selectedCategory = category.rawValue
                                }
                            }
                        }
                    }
                    .padding(15)
                    .background(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .shadow(color: .black.opacity(0.24), radius: 12, x: 0, y: 5)

                    Spacer().frame(height: 14)

                    HStack(spacing: 10) {
                        Button {
                            dismiss()
                        } label: {
                            Text("Cancel")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundStyle(.black)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 18)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(.black, lineWidth: 1))
                        }
                        .buttonStyle(.plain)

                        Button {
                            store.publishAnnouncement(title: title, details: details, category: selectedCategory) { success, message in
                                if success {
                                    title = ""
                                    details = ""
                                    alertText = "Announcement published successfully!"
                                } else {
                                    alertText = message ?? "Unable to publish announcement."
                                }
                            }
                        } label: {
                            Text(store.isPublishing ? "Publishing..." : "Publish")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 18)
                                .background(.black)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                        }
                        .buttonStyle(.plain)
                        .disabled(store.isPublishing)
                    }
                }
                .padding(20)
            }

            BottomNavBar(active: .newPost)
        }
        .background(Color.white.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .alert("ACADvisory", isPresented: Binding(get: { alertText != nil }, set: { if !$0 { alertText = nil } })) {
            Button("OK") {
                let published = alertText == "Announcement published successfully!"
                alertText = nil
                if published {
                    dismiss()
                }
            }
        } message: {
            Text(alertText ?? "")
        }
    }
}

struct FieldLabel: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Color(red: 0.769, green: 0.604, blue: 0.173))
                .frame(width: 21, height: 21)
                .background(Color(red: 1.0, green: 0.91, blue: 0.639))
                .clipShape(RoundedRectangle(cornerRadius: 4))

            Text(text)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(.black)
        }
    }
}

struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    var rowSpacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? 0
        var rows: [[CGSize]] = [[]]
        var currentWidth: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if currentWidth + size.width > maxWidth, !rows[rows.count - 1].isEmpty {
                rows.append([size])
                currentWidth = size.width + spacing
            } else {
                rows[rows.count - 1].append(size)
                currentWidth += size.width + spacing
            }
        }

        let width = rows.map { row in row.reduce(CGFloat(0)) { $0 + $1.width } + CGFloat(max(0, row.count - 1)) * spacing }.max() ?? 0
        let height = rows.reduce(CGFloat(0)) { total, row in total + (row.map(\.height).max() ?? 0) } + CGFloat(max(0, rows.count - 1)) * rowSpacing
        return CGSize(width: min(width, maxWidth), height: height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX
        var y = bounds.minY
        var rowHeight: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if x + size.width > bounds.maxX, x > bounds.minX {
                x = bounds.minX
                y += rowHeight + rowSpacing
                rowHeight = 0
            }

            subview.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(width: size.width, height: size.height))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}
