import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var auth: AuthService
    @Environment(\.dismiss) private var dismiss

    private var displayName: String {
        if let appUser = auth.appUser { return appUser.displayNameUppercase }
        if let name = auth.firebaseUser?.displayName, !name.isEmpty { return name.uppercased() }
        return auth.firebaseUser?.email?.uppercased() ?? "USER"
    }

    private var role: String {
        (auth.appUser?.role ?? "Student").uppercased()
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    BackCircleButton { dismiss() }

                    Spacer().frame(height: 26)

                    HStack {
                        ProfilePill(text: "PROFILE", color: AppTheme.accentYellow)
                        Spacer()
                        NavigationLink(destination: EditProfileView().navigationBarBackButtonHidden(true)) {
                            ProfilePill(text: "EDIT PROFILE", color: AppTheme.softYellow)
                        }
                        .buttonStyle(.plain)
                    }

                    Spacer().frame(height: 16)

                    VStack(spacing: 0) {
                        EditableProfilePhotoView(
                            photoUrl: auth.appUser?.photoUrl ?? auth.firebaseUser?.photoURL?.absoluteString ?? "",
                            photoBase64: auth.appUser?.photoBase64 ?? "",
                            size: 156
                        )

                        Spacer().frame(height: 14)

                        Text(displayName)
                            .font(.system(size: 17, weight: .black))
                            .foregroundStyle(.black)
                            .multilineTextAlignment(.center)

                        Spacer().frame(height: 2)

                        Text(role)
                            .font(.system(size: 17))
                            .foregroundStyle(.black.opacity(0.87))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 18)
                    .padding(.top, 20)
                    .padding(.bottom, 24)
                    .background(AppTheme.profileGray)
                    .clipShape(RoundedRectangle(cornerRadius: 22))

                    Spacer().frame(height: 14)

                    ProfileMenuItem(text: "Language")
                    Spacer().frame(height: 6)
                    ProfileMenuItem(text: "Notification")
                    Spacer().frame(height: 6)
                    ProfileMenuItem(text: "Change Password")
                    Spacer().frame(height: 28)
                    ProfileMenuItem(text: "Help")
                    Spacer().frame(height: 6)
                    ProfileMenuItem(text: "Change User")
                    Spacer().frame(height: 6)
                    ProfileMenuItem(text: "Logout") {
                        auth.logout()
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 22)
                .padding(.bottom, 18)
            }

            BottomNavBar(active: .profile)
                .padding(.top, 0)
        }
        .background(Color.white.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
    }
}

struct EditProfileView: View {
    @EnvironmentObject private var auth: AuthService
    @Environment(\.dismiss) private var dismiss

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var username = ""
    @State private var email = ""
    @State private var didLoad = false
    @State private var showSavedAlert = false

    var body: some View {
        VStack(spacing: 0) {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    BackCircleButton { dismiss() }

                    Spacer().frame(height: 26)

                    HStack {
                        ProfilePill(text: "EDIT PROFILE", color: AppTheme.accentYellow)
                        Spacer()
                        ProfilePill(text: "PROFILE", color: AppTheme.softYellow)
                    }

                    Spacer().frame(height: 16)

                    VStack(spacing: 0) {
                        EditableProfilePhotoView(
                            photoUrl: auth.appUser?.photoUrl ?? auth.firebaseUser?.photoURL?.absoluteString ?? "",
                            photoBase64: auth.appUser?.photoBase64 ?? "",
                            size: 116
                        )

                        Spacer().frame(height: 22)

                        EditProfileTextField(label: "First Name", text: $firstName, isEnabled: !auth.isSavingProfile)
                        Spacer().frame(height: 12)
                        EditProfileTextField(label: "Last Name", text: $lastName, isEnabled: !auth.isSavingProfile)
                        Spacer().frame(height: 12)
                        EditProfileTextField(label: "Username", text: $username, isEnabled: !auth.isSavingProfile)
                        Spacer().frame(height: 12)
                        EditProfileTextField(label: "Email", text: $email, keyboardType: .emailAddress, isEnabled: !auth.isSavingProfile)

                        if let message = auth.profileMessage {
                            Spacer().frame(height: 14)
                            AuthMessageView(text: message)
                        }

                        Spacer().frame(height: 22)

                        RoundedActionButton(
                            title: auth.isSavingProfile ? "Saving..." : "Save Profile",
                            background: .black,
                            foreground: .white,
                            disabled: auth.isSavingProfile
                        ) {
                            auth.saveProfile(firstName: firstName, lastName: lastName, username: username, email: email) {
                                showSavedAlert = true
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 18)
                    .padding(.top, 20)
                    .padding(.bottom, 24)
                    .background(AppTheme.profileGray)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                }
                .padding(.horizontal, 24)
                .padding(.top, 22)
                .padding(.bottom, 18)
            }

            BottomNavBar(active: .profile)
        }
        .background(Color.white.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .onAppear(perform: loadUserDataOnce)
        .onChange(of: auth.appUser) { _ in
            loadUserDataOnce()
        }
        .alert("ACADvisory", isPresented: $showSavedAlert) {
            Button("OK") { dismiss() }
        } message: {
            Text("Profile updated successfully.")
        }
    }

    private func loadUserDataOnce() {
        guard !didLoad else { return }

        if let appUser = auth.appUser {
            firstName = appUser.firstName
            lastName = appUser.lastName
            username = appUser.username
            email = appUser.email.isEmpty ? auth.firebaseUser?.email ?? "" : appUser.email
            didLoad = true
        } else if let user = auth.firebaseUser {
            let displayName = user.displayName ?? ""
            let parts = displayName.components(separatedBy: " ")
            firstName = parts.first ?? ""
            lastName = parts.count > 1 ? parts.dropFirst().joined(separator: " ") : ""
            username = ""
            email = user.email ?? ""
            didLoad = true
        }
    }
}

struct ProfilePill: View {
    let text: String
    let color: Color

    var body: some View {
        Text(text)
            .font(.system(size: 14, weight: .black))
            .foregroundStyle(.black)
            .padding(.horizontal, 18)
            .padding(.vertical, 12)
            .background(color)
            .clipShape(RoundedRectangle(cornerRadius: 25))
    }
}

struct ProfileMenuItem: View {
    let text: String
    var action: (() -> Void)? = nil

    var body: some View {
        Button(action: { action?() }) {
            HStack {
                Text(text)
                    .font(.system(size: 16))
                    .foregroundStyle(.black)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(Color(red: 0.416, green: 0.416, blue: 0.416))
            }
            .padding(.horizontal, 18)
            .frame(height: 52)
            .background(AppTheme.profileGray)
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }
}

struct EditProfileTextField: View {
    let label: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var isEnabled = true

    var body: some View {
        TextField(label, text: $text)
            .font(.system(size: 14))
            .keyboardType(keyboardType)
            .textInputAutocapitalization(keyboardType == .emailAddress ? .never : .words)
            .autocorrectionDisabled(keyboardType == .emailAddress)
            .disabled(!isEnabled)
            .padding(.horizontal, 18)
            .frame(height: 56)
            .background(.white)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(alignment: .topLeading) {
                Text(label)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(Color(red: 0.416, green: 0.416, blue: 0.416))
                    .padding(.horizontal, 4)
                    .background(.white)
                    .offset(x: 16, y: -7)
            }
    }
}
