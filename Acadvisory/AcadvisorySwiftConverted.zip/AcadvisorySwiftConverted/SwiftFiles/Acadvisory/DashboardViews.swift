import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var auth: AuthService
    @EnvironmentObject private var store: AnnouncementStore

    @State private var selectedCategory: String?
    @State private var searchText = ""

    private var filteredAnnouncements: [Announcement] {
        store.announcements.filter { announcement in
            let matchesCategory = selectedCategory == nil || announcement.category == selectedCategory
            let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()

            guard !query.isEmpty else { return matchesCategory }

            let matchesSearch = announcement.title.lowercased().contains(query) ||
                announcement.details.lowercased().contains(query) ||
                announcement.category.lowercased().contains(query)

            return matchesCategory && matchesSearch
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    DashboardUserHeader()

                    Spacer().frame(height: 18)

                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                            .foregroundStyle(.gray)
                        TextField("Search announcements", text: $searchText)
                            .font(.system(size: 13))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                    .padding(.horizontal, 15)
                    .frame(height: 50)
                    .background(.white)
                    .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.gray.opacity(0.35), lineWidth: 1))

                    Spacer().frame(height: 25)

                    Text("Featured Update")
                        .font(.system(size: 15, weight: .bold))

                    Spacer().frame(height: 8)

                    if let first = store.announcements.first {
                        FeaturedUpdateCard(announcement: first)
                    } else {
                        EmptyFeaturedCard()
                    }

                    Spacer().frame(height: 25)

                    Text("Browse")
                        .font(.system(size: 15, weight: .bold))

                    Spacer().frame(height: 10)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(AnnouncementCategory.allCases) { category in
                                CategoryChip(
                                    category: category.rawValue,
                                    selected: selectedCategory == category.rawValue
                                ) {
                                    selectedCategory = selectedCategory == category.rawValue ? nil : category.rawValue
                                }
                            }
                        }
                        .padding(.vertical, 2)
                    }

                    Spacer().frame(height: 20)

                    HStack {
                        Text("Recent Updates")
                            .font(.system(size: 15, weight: .bold))
                        Spacer()
                        if selectedCategory != nil {
                            Button("Clear Filter") {
                                selectedCategory = nil
                            }
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(.gray)
                            .buttonStyle(.plain)
                        }
                    }

                    Spacer().frame(height: 10)

                    recentList
                }
                .padding(20)
            }

            BottomNavBar(active: .home)
        }
        .background(Color.white.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
    }

    @ViewBuilder
    private var recentList: some View {
        if store.announcements.isEmpty {
            Text("No announcements yet.")
                .font(.system(size: 14))
                .foregroundStyle(.gray)
                .frame(maxWidth: .infinity)
                .padding(.top, 30)
        } else if filteredAnnouncements.isEmpty {
            Text(searchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "No \(selectedCategory ?? "") announcements." : "No announcements found.")
                .font(.system(size: 14))
                .foregroundStyle(.gray)
                .frame(maxWidth: .infinity)
                .padding(.top, 30)
        } else {
            LazyVStack(spacing: 10) {
                ForEach(filteredAnnouncements) { announcement in
                    NavigationLink(destination: CalendarView(initialAnnouncementId: announcement.id).navigationBarBackButtonHidden(true)) {
                        UpdateCard(announcement: announcement)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

struct DashboardUserHeader: View {
    @EnvironmentObject private var auth: AuthService

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                ProfilePhotoView(
                    photoUrl: auth.appUser?.photoUrl ?? auth.firebaseUser?.photoURL?.absoluteString ?? "",
                    photoBase64: auth.appUser?.photoBase64 ?? "",
                    size: 40,
                    cornerRadius: 10
                )
                Spacer()
                Circle()
                    .fill(.white)
                    .frame(width: 40, height: 40)
                    .overlay(Image(systemName: "bell").foregroundStyle(.black))
            }

            Spacer().frame(height: 20)

            Text("HELLO,")
                .font(.system(size: 18))
                .foregroundStyle(.black)

            Text(auth.appUser?.firstNameUppercase ?? auth.firebaseUser?.displayName?.components(separatedBy: " ").first?.uppercased() ?? "USER")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.black)

            Text("Stay updated with the latest announcements.")
                .font(.system(size: 12))
                .foregroundStyle(.gray)
        }
    }
}

struct FeaturedUpdateCard: View {
    let announcement: Announcement

    var body: some View {
        NavigationLink(destination: CalendarView(initialAnnouncementId: announcement.id).navigationBarBackButtonHidden(true)) {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(announcement.category.uppercased())
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(AppTheme.categoryStrong(announcement.category))
                        .clipShape(RoundedRectangle(cornerRadius: 8))

                    Spacer().frame(height: 8)

                    Text(announcement.title)
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(.black)

                    Spacer().frame(height: 6)

                    Text(announcement.createdAt.acadvisoryLongString())
                        .font(.system(size: 9))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 15))

                    Spacer().frame(height: 8)

                    Text(announcement.details.acadvisoryLimited())
                        .font(.system(size: 10))
                        .foregroundStyle(.black)
                        .lineLimit(2)

                    Spacer().frame(height: 10)

                    Text("Read more")
                        .font(.system(size: 11))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 15)
                        .padding(.vertical, 7)
                        .background(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                }

                Spacer()

                Image(systemName: "megaphone.fill")
                    .font(.system(size: 58, weight: .bold))
                    .foregroundStyle(.purple)
            }
            .padding(14)
            .frame(maxWidth: .infinity)
            .background(Color(red: 1.0, green: 0.851, blue: 0.416))
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}

struct EmptyFeaturedCard: View {
    var body: some View {
        Text("No featured announcement yet.")
            .font(.system(size: 13))
            .foregroundStyle(.black)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(Color(red: 1.0, green: 0.851, blue: 0.416))
            .clipShape(RoundedRectangle(cornerRadius: 22))
    }
}

struct UpdateCard: View {
    let announcement: Announcement

    var body: some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.white.opacity(0.5))
                .frame(width: 55, height: 55)
                .overlay(
                    Image(systemName: AnnouncementCategory.from(announcement.category).iconName)
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(.black)
                )

            VStack(alignment: .leading, spacing: 3) {
                Text(announcement.title)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.black)
                    .lineLimit(1)
                Text(announcement.createdAt.acadvisoryLongString())
                    .font(.system(size: 10))
                    .foregroundStyle(.gray)
                    .lineLimit(1)
                Text(announcement.details.acadvisoryLimited())
                    .font(.system(size: 10))
                    .foregroundStyle(.black)
                    .lineLimit(1)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(.black)
        }
        .padding(10)
        .background(AppTheme.categoryBackground(announcement.category))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 3)
    }
}
