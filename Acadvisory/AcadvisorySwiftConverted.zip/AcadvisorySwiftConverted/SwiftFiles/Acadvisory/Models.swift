import Foundation
import FirebaseFirestore

struct AppUser: Identifiable, Equatable {
    let id: String
    let uid: String
    var firstName: String
    var lastName: String
    var username: String
    var email: String
    var role: String
    var photoUrl: String
    var photoBase64: String

    init(uid: String, data: [String: Any]) {
        self.id = uid
        self.uid = uid
        self.firstName = data["firstName"] as? String ?? ""
        self.lastName = data["lastName"] as? String ?? ""
        self.username = data["username"] as? String ?? ""
        self.email = data["email"] as? String ?? ""
        self.role = data["role"] as? String ?? "Student"
        self.photoUrl = data["photoUrl"] as? String ?? ""
        self.photoBase64 = data["photoBase64"] as? String ?? ""
    }

    var fullName: String {
        let name = "\(firstName) \(lastName)".trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? email : name
    }

    var displayNameUppercase: String {
        fullName.isEmpty ? "USER" : fullName.uppercased()
    }

    var firstNameUppercase: String {
        if !firstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return firstName.uppercased()
        }

        if !fullName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return fullName.components(separatedBy: " ").first?.uppercased() ?? "USER"
        }

        return email.components(separatedBy: "@").first?.uppercased() ?? "USER"
    }
}

struct Announcement: Identifiable, Equatable {
    let id: String
    var title: String
    var details: String
    var category: String
    var createdAt: Date

    init(id: String, data: [String: Any]) {
        self.id = id
        self.title = data["title"] as? String ?? "No title"
        self.details = data["details"] as? String ?? "No details"
        self.category = data["category"] as? String ?? data["type"] as? String ?? "Events"

        if let timestamp = data["createdAt"] as? Timestamp {
            self.createdAt = timestamp.dateValue()
        } else {
            self.createdAt = Date()
        }
    }
}

enum AnnouncementCategory: String, CaseIterable, Identifiable {
    case academics = "Academics"
    case events = "Events"
    case urgent = "Urgent"
    case organization = "Organization"
    case campusUpdates = "Campus Updates"

    var id: String { rawValue }

    var iconName: String {
        switch self {
        case .academics:
            return "graduationcap.fill"
        case .events:
            return "calendar"
        case .urgent:
            return "exclamationmark.triangle.fill"
        case .organization:
            return "person.3.fill"
        case .campusUpdates:
            return "megaphone.fill"
        }
    }

    static func from(_ value: String) -> AnnouncementCategory {
        AnnouncementCategory(rawValue: value) ?? .events
    }
}
