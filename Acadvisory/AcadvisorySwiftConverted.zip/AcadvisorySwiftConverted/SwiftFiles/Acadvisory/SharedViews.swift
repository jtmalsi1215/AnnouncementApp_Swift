import SwiftUI
import PhotosUI
import UIKit

struct AcadvisoryLogoView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("the")
                .font(.system(size: 42, weight: .light))
                .tracking(2)
                .foregroundStyle(.black)
            Text("ACADvisory")
                .font(.system(size: 44, weight: .black))
                .tracking(-2)
                .foregroundStyle(.black)
            Text("Stay updated with the latest announcements.")
                .font(.system(size: 13))
                .foregroundStyle(Color(red: 0.435, green: 0.435, blue: 0.435))
                .padding(.top, 6)
        }
    }
}

struct AuthInputField: View {
    let placeholder: String
    @Binding var text: String
    var fillColor: Color
    var isSecure: Bool = false
    var hasShadow: Bool = false
    var keyboardType: UIKeyboardType = .default
    var isEnabled: Bool = true

    var body: some View {
        Group {
            if isSecure {
                SecureField(placeholder, text: $text)
            } else {
                TextField(placeholder, text: $text)
                    .keyboardType(keyboardType)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
        }
        .font(.system(size: 14))
        .disabled(!isEnabled)
        .padding(.horizontal, 32)
        .frame(height: 58)
        .background(fillColor)
        .clipShape(RoundedRectangle(cornerRadius: 30))
        .shadow(color: hasShadow ? .black.opacity(0.22) : .clear, radius: 6, x: 0, y: 4)
    }
}

struct AuthMessageView: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(.red)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(Color.red.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.red.opacity(0.18), lineWidth: 1)
            )
    }
}

struct RoundedActionButton: View {
    let title: String
    let background: Color
    let foreground: Color
    var disabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 20, weight: .heavy))
                .foregroundStyle(foreground)
                .frame(maxWidth: .infinity)
                .frame(height: 60)
                .background(background)
                .clipShape(RoundedRectangle(cornerRadius: 30))
                .opacity(disabled ? 0.7 : 1)
        }
        .disabled(disabled)
        .buttonStyle(.plain)
    }
}

struct BackCircleButton: View {
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: "chevron.left")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(Color(red: 0.416, green: 0.416, blue: 0.416))
                .frame(width: 52, height: 52)
                .background(.white)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color(red: 0.741, green: 0.741, blue: 0.741), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct BottomNavBar: View {
    enum ActiveItem {
        case home
        case calendar
        case newPost
        case profile
    }

    let active: ActiveItem

    var body: some View {
        HStack {
            navItem(icon: "house.fill", item: .home, destination: AnyView(DashboardView()))
            navItem(icon: "calendar", item: .calendar, destination: AnyView(CalendarView()))
            navItem(icon: "bubble.left", item: .newPost, destination: AnyView(NewAnnouncementView()))
            navItem(icon: "person", item: .profile, destination: AnyView(ProfileView()))
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .background(.black)
        .clipShape(RoundedRectangle(cornerRadius: 35))
        .padding(15)
    }

    @ViewBuilder
    private func navItem(icon: String, item: ActiveItem, destination: AnyView) -> some View {
        if active == item {
            Image(systemName: icon)
                .font(.system(size: 19, weight: .semibold))
                .foregroundStyle(.black)
                .frame(width: 42, height: 42)
                .background(.white)
                .clipShape(Circle())
                .frame(maxWidth: .infinity)
        } else {
            NavigationLink(destination: destination.navigationBarBackButtonHidden(true)) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(.black)
                    .clipShape(Circle())
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
        }
    }
}

struct HeaderPlaceholderView: View {
    var body: some View {
        HStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.gray.opacity(0.28))
                .frame(width: 40, height: 40)
            Spacer()
            Circle()
                .fill(.white)
                .frame(width: 40, height: 40)
                .overlay(Image(systemName: "bell").foregroundStyle(.black))
        }
    }
}

struct ProfilePhotoView: View {
    let photoUrl: String
    let photoBase64: String
    let size: CGFloat
    let cornerRadius: CGFloat
    var personIconColor: Color = .black.opacity(0.52)

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius)
                .fill(Color.gray.opacity(0.28))

            if let image = base64Image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            } else if !photoUrl.isEmpty, let url = URL(string: photoUrl) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    default:
                        Image(systemName: "person.fill")
                            .font(.system(size: size * 0.45))
                            .foregroundStyle(personIconColor)
                    }
                }
                .frame(width: size, height: size)
                .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            } else {
                Image(systemName: "person.fill")
                    .font(.system(size: size * 0.45))
                    .foregroundStyle(personIconColor)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
    }

    private var base64Image: UIImage? {
        guard !photoBase64.isEmpty, let data = Data(base64Encoded: photoBase64) else { return nil }
        return UIImage(data: data)
    }
}

struct EditableProfilePhotoView: View {
    @EnvironmentObject private var auth: AuthService
    let photoUrl: String
    let photoBase64: String
    let size: CGFloat
    @State private var selectedItem: PhotosPickerItem?
    @State private var toastText: String?

    var body: some View {
        VStack(spacing: 8) {
            PhotosPicker(selection: $selectedItem, matching: .images) {
                ZStack(alignment: .bottomTrailing) {
                    ProfilePhotoView(
                        photoUrl: photoUrl,
                        photoBase64: photoBase64,
                        size: size,
                        cornerRadius: size / 2,
                        personIconColor: .white
                    )
                    .background(Color(red: 0.722, green: 0.722, blue: 0.722))
                    .clipShape(Circle())

                    ZStack {
                        Circle()
                            .fill(.black)
                            .frame(width: 38, height: 38)
                            .overlay(Circle().stroke(.white, lineWidth: 3))

                        if auth.isUploadingPhoto {
                            ProgressView()
                                .tint(.white)
                                .scaleEffect(0.75)
                        } else {
                            Image(systemName: "camera.fill")
                                .font(.system(size: 16))
                                .foregroundStyle(.white)
                        }
                    }
                }
            }
            .buttonStyle(.plain)
            .disabled(auth.isUploadingPhoto)
            .onChange(of: selectedItem) { item in
                Task {
                    guard let data = try? await item?.loadTransferable(type: Data.self),
                          let image = UIImage(data: data),
                          let compressed = image.acadvisoryCompressedProfileData() else {
                        toastText = "Unable to save profile picture. Please choose a smaller image."
                        return
                    }

                    auth.saveProfileImage(compressed) { success in
                        toastText = success ? "Profile picture saved." : "Unable to save profile picture. Please choose a smaller image."
                    }
                }
            }

            Text("Tap photo to choose")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Color(red: 0.416, green: 0.416, blue: 0.416))
        }
        .alert("ACADvisory", isPresented: Binding(get: { toastText != nil }, set: { if !$0 { toastText = nil } })) {
            Button("OK", role: .cancel) { toastText = nil }
        } message: {
            Text(toastText ?? "")
        }
    }
}

struct CategoryChip: View {
    let category: String
    var selected: Bool = false
    var smallText: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: AnnouncementCategory.from(category).iconName)
                    .font(.system(size: smallText ? 13 : 15, weight: .semibold))
                    .foregroundStyle(AppTheme.categoryStrong(category))
                Text(category)
                    .font(.system(size: smallText ? 8 : 11, weight: .semibold))
                    .foregroundStyle(.black)
            }
            .padding(.horizontal, smallText ? 8 : 10)
            .padding(.vertical, smallText ? 7 : 8)
            .background(AppTheme.categoryBackground(category))
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(selected ? .black : .clear, lineWidth: 1.3)
            )
            .shadow(color: .black.opacity(0.12), radius: 4, x: 0, y: 2)
        }
        .buttonStyle(.plain)
    }
}
